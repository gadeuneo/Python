from PIL import Image
import requests
from io import BytesIO

url = 'https://vetstreet.brightspotcdn.com/dims4/default/5b3ffe7/2147483647/thumbnail/180x180/quality/90/?url=https%3A%2F%2Fvetstreet-brightspot.s3.amazonaws.com%2F8e%2F4e3910c36111e0bfca0050568d6ceb%2Ffile%2Fhub-dogs-puppy.jpg'
response = requests.get(url)
img = Image.open(BytesIO(response.content))

img = np.array(img.resize((224,224)))
img = img.reshape(1, 224, 224, 3)
res = model.predict(img)
pred_class = np.argmax(res)
